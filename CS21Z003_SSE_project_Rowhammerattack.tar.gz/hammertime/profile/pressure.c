/*
 * Copyright (c) 2018 Vrije Universiteit Amsterdam
 *
 * This program is licensed under the GPL2+.
 */

#if defined(unix) || defined(__unix) || defined(__unix__)
#include "pressure_pthread.h"
#endif
