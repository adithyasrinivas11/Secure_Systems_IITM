/*
 * Copyright (c) 2018 Vrije Universiteit Amsterdam
 *
 * This program is licensed under the GPL2+.
 */

#ifndef RAMSES_MAP_NAIVE_MSYS_H
#define RAMSES_MAP_NAIVE_MSYS_H 1

#include "msys_int.h"

extern const struct MapConfig MAP_NAIVE_CONFIG;

#endif /* naive_msys.h */
